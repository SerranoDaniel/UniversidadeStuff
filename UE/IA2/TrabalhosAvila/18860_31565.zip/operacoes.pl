
:- dynamic(path/1).
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% restrições do tabuleiro 

restri((1,2),(1,3)).
restri((1,3),(1,2)).
restri((2,3),(2,2)).
restri((2,2),(2,3)).
restri((3,4),(4,4)).
restri((4,4),(3,4)).
restri((4,5),(3,5)).
restri((3,5),(4,5)).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
estado_inicial((18,18)). 
estado_final((26,26)).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% operações para mudança de local 
%% pni %%

% cima 
op((X,Y),cima,(Z,Y),1):- X > 1, Z is X-1, (path((Z,Y))
												-> fail
												;assertz(path((Z,Y)))).
% baixo 
op((X,Y),baixo,(Z,Y),1):- X < 30, Z is X+1, (path((Z,Y))
												-> fail 
												;assertz(path((Z,Y)))).
% direita
op((X,Y),direita,(X,Z),1):- Y < 30, Z is Y+1, (path((X,Z))
												-> fail
												;assertz(path((X,Z)))).
% esquerda 
op((X,Y),esquerda,(X,Z),1):- Y > 1, Z is Y-1, (path((X,Z))
												-> fail
												;assertz(path((X,Z)))).



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% 1 ª Euclidiana  

h((Xi,Yi),V):- estado_final((Xf,Yf)), V is (Xf - Xi) + (Yf - Yi).

% 2 º declive da recta 

h((Xi,Yi),V):- estado_final((Xf,Yf)), Xf \= Xi, V is (Yf - Yi)/ (Xf - Xi).
h((Xi,Yi),V):- estado_final((Xf,Yf)), Xf = Xi,V is 0.

