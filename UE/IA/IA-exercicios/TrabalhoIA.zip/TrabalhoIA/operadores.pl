
:- dynamic(caminho/1).
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


porta_bloq((1,2),(1,3)).
porta_bloq((1,3),(1,2)).
porta_bloq((2,3),(2,2)).
porta_bloq((2,2),(2,3)).
porta_bloq((3,4),(4,4)).
porta_bloq((4,4),(3,4)).
porta_bloq((4,5),(3,5)).
porta_bloq((3,5),(4,5)).



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

estado_inicial((18,18)).
estado_final((26,26)).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




op((X,Y),sobe,(Z,Y),1):- 
	X > 1, 
	Z is X-1,
    \+porta_bloq((X,Y),(Z,Y)),
	(caminho((Z,Y))
		-> fail
		;assertz(caminho((Z,Y)))
	).


op((X,Y),desce,(Z,Y),1):- 
	X < 30, 
	Z is X+1,
    \+porta_bloq((X,Y),(Z,Y)),
	(caminho((Z,Y))
		-> fail 
		;assertz(caminho((Z,Y)))
	).



op((X,Y),direita,(X,Z),1):- 
	Y < 30, 
	Z is Y+1,
    \+porta_bloq((X,Y),(X,Z)),
	(caminho((X,Z))
		-> fail
		;assertz(caminho((X,Z)))
	).

 
op((X,Y),esquerda,(X,Z),1):- 
	Y > 1, 
	Z is Y-1,
    \+porta_bloq((X,Y),(X,Z)),
	(caminho((X,Z))
		-> fail
		;assertz(caminho((X,Z)))
	).



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%h((X,Y), H):- 
%	estado_final((W,Z)),
 %  	CoordX is abs(W-X),
  %  CoordY is abs(Z-Y),
   % H is CoordY + CoordX.



h((X,Y), H):- 
	estado_final((W,Z)),
 	 CoordX is abs(W-X),
	CoordY is abs(Z-Y),
	H is round(sqrt(CoordY*CoordY + CoordX*CoordX)).
