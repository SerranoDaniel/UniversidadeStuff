# cliente exemplo 
import socket, select, sys
 
def prompt() :
    sys.stdout.write('\ncomand:\n')
    sys.stdout.flush()
 
#main function
if __name__ == "__main__":
     
    host = '127.0.0.1' # ou outro host
    port = 5000        # ou outra porta
     
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(2)
     
    # liga ao host remoto
    try :
        s.connect((host, port))
    except :
        print('Unable to connect')
        sys.exit()
     
    print('Connected to remote host.\n')
    print('type help for the list of comands')
    prompt()

    
    while True:
        message = sys.stdin.readline()
        message = message.encode('utf-8')
        s.send(message)
        socket_list = [s]
         
        # Espera por um socket com dados
        read_sockets, write_sockets, error_sockets = select.select(socket_list , [], [])
         
        for sock in read_sockets:
            #chegou uma mensagem no socket
            if sock == s:
                data = sock.recv(4096)
                data= data.decode()
                if not data :
                    print('\nDisconnected from server')
                    sys.exit()
                else :                                        
                    sys.stdout.write(data)
                    sys.stdout.flush()
                    if(data=='Logged Off\n'):
                        sys.exit()
                                  
                    
        prompt()
                
