# -*- coding: utf-8 -*-
import socket, select
from time import gmtime, strftime

SOCKET_LIST = []    # lista de sockets abertos
RECV_BUFFER = 4096  # valor recomendado na doc. do python
PORT = 5000
SOCKET_LOGIN = [] #lista com sockets com login efectuado
USER_LOGIN = []

def VerifyUser(user):
    username = USER_LOGIN[SOCKET_LOGIN.index(sock)]
    if(user==username):
        return True
    else:
        return False
def Pubmsgs():
    pubmsgs = ''    
    try:
        file = open('pubMsgs.txt', 'r')
    except:
        return 'Nao existem mensagens publicas\n'
    while True:
        line = file.readline()
        if (''==line or '\n'==line):
            break
        else:
            day1, day2, mon, year, time, hzone, user, msg = line.split(" ", 7)
            pubmsgs+= day1+' '+day2+' '+mon+' '+year+' '+ time +' '+ hzone+' - '+ user+': '+msg
    if(pubmsgs==''):
        pubmsgs='Nao existem mensagens publicas\n'
        return pubmsgs
    else:
        return pubmsgs    

def Privmsgs():
    username = USER_LOGIN[SOCKET_LOGIN.index(sock)]
    privmsgs = ''    
    try:
        file = open('privMsgs.txt', 'r')
    except:
        return 'Nao existem mensagens privadas\n'
    while True:
        line = file.readline()
        if (''==line or '\n'==line):
            break
        else:
            day1, day2, mon, year, time, hzone, user, receiver, msg = line.split(" ", 8)            
            if(username==receiver):
                privmsgs+=day1+' '+day2+' '+mon+' '+year+' '+ time +' '+ hzone+' - '+ user+': '+msg
    if(privmsgs ==''):
        privmsgs='Nao existem mensagens privadas para este utilizador\n'
        return privmsgs
    else:
        return privmsgs            

def writePubMsg(username, message):
    time = strftime('%a, %d %b %Y %H:%M:%S +0000', gmtime())
    file = open('pubMsgs.txt', 'a')
    file.write(time + ' '+ username + ' ' +  message)
    file.close()

def writePrivMsg(username, destiny, message):
    time = strftime('%a, %d %b %Y %H:%M:%S +0000', gmtime())    
    file = open('privMsgs.txt', 'a')
    file.write(time + ' ' +username + ' ' + destiny + ' '+ message)
    file.close()

def writeReg (username, password):
    file = open('autenticationFile.txt', 'a')
    file.write(username+' '+password)
    file.close()
    

def consultReg (username, password, mode):
    try:
        file = open('autenticationFile.txt', 'r')
    except:
        return False
    while True:
        line = file.readline()
        if (''==line or '\n'==line):
            return False
        user, key = line.split(" ",1)
        if (username == user):
            if(mode ==0):
                return True
            if key.replace("\n","") == password.replace("\n",""): # o \n Ã© por o new line da pass
                return True            
    return False 

def usersonline():
    username = USER_LOGIN[SOCKET_LOGIN.index(sock)]
    users = ''
    for x in USER_LOGIN:
        if(x!=username):
            users+=x+'-->'
    if(users==''):
        users+='Não existem users online\n'
        return users
    else:
        return users+'\n'

def process_cmd(data, sock):
    # this is the function that processes data received from a client on
    # socket 'sock'
    data= data.decode('utf-8')
    if data:
        if(" " in data):
            a,b = data.split(" ", 1)
            a=a.upper()
            print(a)
            if(a=="SENDMSG"):
                if (sock in SOCKET_LOGIN):
                        print( "mensagem: " + b)
                        username = USER_LOGIN[SOCKET_LOGIN.index(sock)]
                        writePubMsg(username, b)
                        awnser = 'mensagem enviada com sucesso\n'
                        awnser=awnser.encode()
                        sock.send(awnser)
                        
                else:
                    awnser = 'Precisa de fazer o login primeiro\n'
                    awnser=awnser.encode()
                    sock.send(awnser)
                    

            elif(a=="SENDPRIVMSG"):
                if (sock in SOCKET_LOGIN):
                    if(" " in b):
                        c, d = b.split(" ", 1)
                        if(VerifyUser(c)):
                            awnser = 'O destinatario e o mesmo user que o remetente \n'
                            awnser=awnser.encode()
                            sock.send(awnser)
                        elif((consultReg(c, d, 0))):
                            print("manda mensagem  privada para : " + c)
                            print( "mensagem: " + d)
                            username = USER_LOGIN[SOCKET_LOGIN.index(sock)]
                            writePrivMsg(username, c, d)
                            awnser = 'mensagem enviada com sucesso\n'
                            awnser=awnser.encode()
                            sock.send(awnser)
                        else:
                            awnser = 'Username nao encontrado\n'
                            awnser=awnser.encode()
                            sock.send(awnser)
                        
                    else:
                        print("comando errado")
                else:
                    awnser = 'Precisa de fazer o login primeiro\n'
                    awnser=awnser.encode()
                    sock.send(awnser)
                    
            elif(a=="REGISTER"):
                if(" " in b):
                    c, d = b.split(" ", 1)
                    print("username: "+c)
                    print("password: " +d)
                    if ' ' in d:
                        awnser = 'password tem que ser inserida sem espaços\n'
                        awnser = awnser.encode()
                        sock.send(awnser)
                    if (sock in SOCKET_LOGIN):
                        awnser = 'Login ja efetuado\n'
                        awnser = awnser.encode()
                        sock.send(awnser)
                    else:
                        if(consultReg(c, d, 0)):
                            awnser = 'Nome já registado\n'
                            awnser=awnser.encode()
                            sock.send(awnser)
                        else:
                            writeReg(c,d)
                            awnser = 'Registo efectuado com sucesso\n'
                            awnser=awnser.encode()
                            sock.send(awnser)
                    
                else:
                    print("comando errado")
                    l = 'Comando errado tente novamente\n'
                    l=l.encode()
                    sock.send(l)
            elif(a=="LOGIN"):
                if(" " in b):
                    c, d = b.split(" ", 1)
                    print("username: "+c)
                    print("password: " +d)  
                    if ' ' in d:
                        awnser = 'password tem que ser inserida sem espaços\n'
                        awnser = awnser.encode()
                        sock.send(awnser)
                    if (sock in SOCKET_LOGIN):
                        awnser = 'Login ja efetuado\n'
                        awnser = awnser.encode()
                        sock.send(awnser)
                    else:
                        if (consultReg(c, d, 1)):
                            SOCKET_LOGIN.append(sock)
                            USER_LOGIN.append(c)
                            username = USER_LOGIN[SOCKET_LOGIN.index(sock)]
                            print(username)
                            awnser = 'Login efetuado com sucesso\n'
                            awnser=awnser.encode()
                            sock.send(awnser)
                        else:
                            awnser = 'Utilizador ou Password errados\n'
                            awnser=awnser.encode()
                            sock.send(awnser)
                else:
                    print("comando errado")
                    awnser = 'Utilizador ou Password errados\n'
                    awnser=awnser.encode()
                    sock.send(awnser)
            else:
                print("comando errado")
                l = 'Comando errado tente novamente\n'
                l=l.encode()
                sock.send(l) 
        else:
            data = data.upper()
            if(data=="PRIVMSGS\n"):                
                if (sock in SOCKET_LOGIN):                    
                    print("retorna lista mensagens privadas do utilizador")
                    l = Privmsgs()
                    l=l.encode()
                    sock.send(l)
                else:
                    l = 'Necessita de fazer login para aceder a este comando\n'
                    l=l.encode()
                    sock.send(l)       
            elif(data=="WHOSONLINE\n"):
                if (sock in SOCKET_LOGIN):                    
                    print("retorna lista de users online")
                    l = usersonline()
                    l = l.encode()
                    sock.send(l)                    
                else:
                    l = 'Necessita de fazer login para aceder a este comando\n'
                    l=l.encode()
                    sock.send(l)                             
            elif(data=="PUBLICMSGS\n"):
                if (sock in SOCKET_LOGIN):
                    print("retorna lista mensagens publicas do utilizador")
                    l = Pubmsgs()
                    l=l.encode()
                    sock.send(l)
                else:
                    l = 'Necessita de fazer login para aceder a este comando\n'
                    l=l.encode()
                    sock.send(l)                    
            elif(data=="GOODBYE\n"):
                print("Logged off")
                l = 'Logged Off\n'
                l=l.encode()
                sock.send(l)
                username = USER_LOGIN[SOCKET_LOGIN.index(sock)]
                SOCKET_LIST.remove(sock)
                SOCKET_LOGIN.remove(sock)
                USER_LOGIN.remove(username)                
                sock.close()
            elif(data=="HELP\n"):
                if(sock in SOCKET_LOGIN):
                    l = '| sendmsg mensagem | para enviar mensagem publica\n| sendprivmsg destino mensagem | para enviar mensagem privada\n'
                    l+='| publicmsgs | para consultar mensagens publicas\n| privmsgs | para consultar mensagens privadas\n| whosonline | para consultar os users que estao online\n| goodbye | para fazer logg off\n'
                    l=l.encode()
                    sock.send(l)
                else:
                    l = '| register nome pass | para efetuar registo\n| login nome pass | para efetuar login\n| goodbye | para sair\n'
                    l=l.encode()
                    sock.send(l)                
            else:
                print("Comando Errado")
                l = 'Comando errado tente novamente\n'
                l=l.encode()
                sock.send(l)

'''
        if data = 'login':# switch
            if sock in SOCKET_LOGIN:
                info = 'Ja efetuou o login'
                info = info.encode()
                sock.send(info)
            else:
                 #Acede ao ficheiro de login e verifica se o util e pass dao match
                 #Caso não, retorna uma frase
                 #Caso sim, adiciona à lista de login e retorna mensagem

                
        if data = 'Registo':
            #Leitor de ficheiro verifica se já existe o registo
            #Caso sim devolve uma mensagem, caso não insere o novo registo
        
 '''           

if __name__ == "__main__":
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server_socket.bind(("0.0.0.0", PORT))  # aceita ligações de qualquer lado
    server_socket.listen(10)
    server_socket.setblocking(0) # we'll use select(), so no blocking
    
    # Add server socket to the list of readable connections
    SOCKET_LIST.append(server_socket)
    
    print("Server started on port %d" % (PORT,))

    while True:  # server loop

        # remove closed socks
        for sock in SOCKET_LIST:
            if sock.fileno() < 0:  # something closed the socket
                SOCKET_LIST.remove(sock)
                
        rsocks,wsocks,esocks = select.select(SOCKET_LIST,[],[])
 
        for sock in rsocks:  # rsocks are sockets with new data
             
            if sock == server_socket: # new client connection
                newsock, addr = server_socket.accept()
                newsock.setblocking(0)
                SOCKET_LIST.append(newsock)

                print("New client - %s" % (addr,))
                 
            else: # há dados num socket ligado a um cliente
                try:
                    data = sock.recv(RECV_BUFFER)
                    print(data.decode())
                    if data:
                        process_cmd(data, sock) # process this client's data
                     
                    else: # não há dados, o cliente fechou o socket
                        print("Client disconnected 1")
                        sock.close()
                        SOCKET_LIST.remove(sock)
                        
                except Exception as e: # excepção ao ler o socket, o cliente fechou ou morreu
                    print("Client disconnected")
                    sock.close()
                    SOCKET_LIST.remove(sock)
                    
                    
