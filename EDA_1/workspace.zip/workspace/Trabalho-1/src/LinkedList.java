
public class LinkedList<T> implements Iterable<T>{ 
	DoubleNode<T> header;
	public int size;
	
	public LinkedList(){
		header= new DoubleNode<T>();
		this.size=0;
	}
	
	public java.util.Iterator<T> iterator(){
		return new Iterador<T>(header.next);
	}
	
	public int size(){
		return size;
	}
	
	public boolean isEmpty(){
		return size==0;		
	}
	
	public DoubleNode<T> getNode(int i){
		int counter=0;
		DoubleNode<T> element=this.header.next;		
		while(counter<i){
			element=element.next;
			counter++;
		}
		return element;	
	}
	
	public void add(T t){
		java.util.Iterator<T> iterador=new Iterador<T>(this.header.next);
		DoubleNode<T> element=this.header;
		while(iterador.hasNext()==true){			
			iterador.next();
			element=element.next;
		}
		DoubleNode<T> tt=new DoubleNode<T>(t, element);
		element.next=tt;
		size++;
	}
	
	public void add(int i, T t){
		int counter=0;
		java.util.Iterator<T> iterador=new Iterador<T>(this.header.next);
		DoubleNode<T> element=this.header;		
		while(counter<i){
			iterador.next();
			element=element.next;
			counter++;
		}
		DoubleNode<T> tt= new DoubleNode<T>(t, element);
		tt.next=element.next;
		(element.next).prev=tt;
		element.next=tt;
		size++;		
	}
	
	public void remove(int i){
		int counter=0;
		java.util.Iterator<T> iterador=new Iterador<T>(this.header.next);
		DoubleNode<T> element=this.header;		
		while(counter<i){
			iterador.next();
			element=element.next;
			counter++;
		}
		element.next=(element.next).next;
		(element.next).prev=element;
		size--;
	}
	
	public void remove(T t){
		java.util.Iterator<T> iterador=new Iterador<T>(this.header.next);
		DoubleNode<T> element=this.header;
		
		for(int i=0;i<this.size;i++){
			if((element.next).getElemento()==t){
				element.next=(element.next).next;
				(element.next).prev=element;
				size--;
			}
			else{
				iterador.next();
				element=element.next;
			}
		}				
	}
	
	public String toString(){
		String s = new String();
		java.util.Iterator<T> iterador=new Iterador<T>(this.header.next);
		
		while(iterador.hasNext()){
			s+= iterador.next()+"-->"+" ";
		}
		return s;
	}
	public String toString2(){
		String s = new String();
		java.util.Iterator<T> iterador=new Iterador<T>(this.header.next);
		
		while(iterador.hasNext()){
			s+= iterador.next()+" ";
		}
		return s;
	}
}	
