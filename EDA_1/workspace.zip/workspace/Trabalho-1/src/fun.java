public class fun {
	
	public static boolean isParentO(String s){
		switch(s){
			case "(":
				return true;
			default:
				return false;
		}
	}
	public static boolean isParentC(String s){
		switch(s){
			case ")":
				return true;
			default:
				return false;
		}
	}	
//Retorna prioridade de operador
	public static int priority(String s){
		int j=0;
		switch(s){
			case "(":
				j=2;
				break;
			case "*":
			case "/":
				j=1;
				break;
			case "+":
			case "-":
				j=0;
				break;
			default:
				break;
		}
		return j;		
	}
//Verifica se � numero
	public static boolean isNum(String s){
		int j=0;
		for(int i=0; i<s.length();i++){
			if(s.charAt(i)>='0' && s.charAt(i)<='9'){
				j++;
			}
		}
		if(j==0){
			return false;
		}
		return j==s.length();
	}
//Verifica se � operador
	public static boolean isOperator(String s){
		switch(s){
			case "+":
			case "-":
			case "*":
			case "/":
				return true;			
			default:
				return false;
		}
	}
	
//Converte input String[]array
	public static String[] toArray(String s){
		String[] arrays = new String[s.length()];
		for(int k=0; k<s.length();k++){
			arrays[k]="";
		}
		
		int j=0;
		for(int i=0; i<s.length();i++){
			if(i<=s.length()-1 && isNum(s.charAt(i)+"")){;
				while(i<=s.length()-1 && isNum(s.charAt(i)+"")){
					arrays[j]+=s.charAt(i)+"";
					i++;
				}
			i--;	
			j++;
			}
			else if(isOperator(s.charAt(i)+"")){
				arrays[j]=s.charAt(i)+"";
				j++;
			}
			else if(isParentO(s.charAt(i)+"") || isParentC(s.charAt(i)+"")){
				arrays[j]=s.charAt(i)+"";
				j++;
			}
		}
		return arrays;
	}

	
	public static String[] arrayPost(String[] s){
		String[] post = new String[s.length];
		ArrayStack<String> stack=new ArrayStack<String>(20);
		int i=0;
		int j=0;
		while(i<=s.length-1 && s[i]!=""){
			if(isNum(s[i])){
				post[j]=s[i];
				j++;
				i++;
			}
			else if(isParentO(s[i])){//parentese a abrir
				stack.push(s[i]);
				i++;
			}
			else{
				if(stack.top()==null){
					stack.push(s[i]);
					i++;
				}
				else if(isParentC(s[i])){//parentese a fechar
					while(!stack.isEmpty() && !isParentO(stack.top())){
						post[j]=stack.pop();
						j++;
					}
					stack.pop();
					i++;
				}
				else{
					if(priority(s[i]) >= priority(stack.top())){
						stack.push(s[i]);
						i++;
					}
					else{
						if(!stack.isEmpty() && priority(s[i])<priority(stack.top())){
							stack.push(s[i]);
							i++;
						}
						else{
							while(!stack.isEmpty() && priority(stack.top())>=priority(s[i])){
								if(isOperator(stack.top())){
								post[j]=stack.pop();
								j++;
								}
								else{
									stack.pop();
								}
							}
							stack.push(s[i]);
							i++;
						}
					}
				}
			}
		}
		while(!stack.isEmpty()){
			if(!isParentO(stack.top())){
				post[j]=stack.pop();
				j++;
			}
			else{
			stack.pop();
			}
		}
	return post;
	}
	
	public static boolean correct(String[] s){
		return isCorrect(s) && isBalanced(s);
	}
	
	public static boolean isCorrect(String[] s){
		int i=0;
		boolean t=false;
		while(i<s.length && s[i]!=null && s[i]!=""){
			if(i<=s.length-1 &&isParentO(s[i]) && isParentC(s[i+1])){
				t=false;
				break;
			}
			else if(isOperator(s[0])){
				t=false;
				break;
			}
			else if(i==s.length-1 && isOperator(s[i])){
				t=false;
				break;
			}
			else if(i==s.length-1 && isParentO(s[i])){
				t=false;
				break;
			}			
			else if(isOperator(s[i]) && isOperator(s[i+1])){
				t=false;
				break;
			}			
			else if(!isOperator(s[i]) && !isParentO(s[i]) && !isParentC(s[i]) && !isNum(s[i]) ){
				t=false;
				break;
			}
			else{
				t=true;
				i++;
			}
		}
		return t;
	}
	
	public static boolean isBalanced(String[] s){
		ArrayStack<String> temp = new ArrayStack<String>(10);
		int i=0;
		boolean x=true;
		while(i<=s.length-1 && s[i]!=null){
			if(isParentO(s[i])){
				temp.push(s[i]);
				i++;
			}
			else if(!temp.isEmpty() && isParentC(s[i])){
				temp.pop();
				i++;
			}
			else if(temp.isEmpty() && isParentC(s[i])){
				x=false;
				i++;
			}
			else{
				i++;
			}
		}
		return temp.isEmpty() && x==true;
	}
	
	public static BinaryTreeRoot<String> Tree(String[] s){
		int i=0;
		BinaryTreeRoot<String> r = new BinaryTreeRoot<String>();
		ArrayStack<BinaryTree<String>> num= new ArrayStack<BinaryTree<String>>(20);
		while(i<=s.length-1 && s[i]!=null){
			if(isNum(s[i])){
				BinaryTree<String> temp= new BinaryTree<String>(s[i]);
				num.push(temp);
				i++;
			}
			else{
				BinaryTree<String> temp= new BinaryTree<String>(s[i]);
				temp.filhoD = num.pop();
				temp.filhoE = num.pop();
				r.setRaiz(temp);
				num.push(temp);
				i++;
			}
		}
		return r;
	}
}
