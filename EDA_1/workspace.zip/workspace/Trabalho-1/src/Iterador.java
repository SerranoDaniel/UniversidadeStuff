
public class Iterador<E> implements java.util.Iterator<E>{
	
	private DoubleNode<E> current;
	
	public Iterador(DoubleNode<E> s){
		this.current=s;
	}
	
	public boolean hasNext(){
		return current!=null;
	}
	
	public E next(){
		if(!this.hasNext()){
			throw new java.util.NoSuchElementException( );
		}
		else{
			E e = current.getElemento();
			current=current.next;
			return e;
		}
	}
}
