public class BinaryTreeRoot<T> {
	BinaryTree<T> raiz ;
	
	public BinaryTreeRoot(){
		this.raiz=null;
	}
	
	public void setRaiz(BinaryTree<T> t){
		this.raiz=t;
	}
	public BinaryTree<T> getRaiz(){
		return this.raiz;
	}
	public int findHeight(BinaryTree<T> t){
		int i=0;
		i=Height(t);
		return i;
	}
	
	private int Height(BinaryTree<T> t) {
		 if (t == null){
			 return -1;
		 }
		 else{
			 return 1+ Math.max(findHeight(t.filhoE), findHeight(t.filhoD));  
		 }
	}
	
	public String toString(BinaryTree<T> t) {
        if (t.isFolha()) {
            return t.elemento.toString();
        }
        else {
            String raiz, filhoE = "null", filhoD = "null";
            raiz = t.elemento.toString();
            if (t.getE() != null) {
                filhoE = t.getE().toString();
            }
            if (t.getD() != null) {
                filhoD = t.getD().toString();
            }
            return raiz + " (" + filhoE + ", " + filhoD + ")";
        }
    }
	
	public LinkedList<String> toPostfix(BinaryTree<T> t){
		LinkedList<String> l1 = new LinkedList<String>();
		postOrder(t, l1);
		return l1;
	}
	
	private void postOrder(BinaryTree<T> r, LinkedList<String> l1){
		if(!r.isFolha()){
			postOrder(r.filhoE, l1);			
			postOrder(r.filhoD, l1);
			l1.add(r.getElemento()+"");
		}
		else{
			l1.add(r.getElemento()+"");
		}

	}
	public LinkedList<String> toOperator(BinaryTree<T> t){
		LinkedList<String> l1 = new LinkedList<String>();
		operator(t, l1);
		return l1;
	}
	
	private void operator(BinaryTree<T> r, LinkedList<String> l1){
		if(!r.isFolha()){
			operator(r.filhoE, l1);
			operator(r.filhoD, l1);			
		}
		else{
			l1.add(r.getElemento()+"");
		}
	}
	
	public double avalia(){
		return avalia(raiz);
	}
	
	private double avalia(BinaryTree<T> r){
		if(r.isFolha()){
			return Double.parseDouble(r.elemento+"");
		}
		if(r.elemento.equals("+")){
			return avalia(r.filhoE)+avalia(r.filhoD);
		}
		if(r.elemento.equals("-")){
			return avalia(r.filhoE)-avalia(r.filhoD);
		}
		if(r.elemento.equals("*")){
			return avalia(r.filhoE)*avalia(r.filhoD);
		}
		if(r.elemento.equals("/")){
			return avalia(r.filhoE)/avalia(r.filhoD);
		}
		return 0;
	}
	
	private void addTree(BinaryTree<T> x, int coordX, int coordY, GraphDraw f,int j,int nivel,int larg){
	    if(x!=null){
	      f.addNode(x.elemento.toString(), coordX,coordY);
	      int i=f.nodesSize()-1;
	      //System.out.println(i);
	      if(j!=-1){
	        f.addEdge(j,i);  
	      }
	      int n=(int)Math.pow(2,nivel);
	      int dist=larg/(2*n);
	      if(x.filhoE!=null)
	        addTree(x.filhoE,coordX-dist,coordY+50,f,i,nivel+1,larg);
	      
	      if (x.filhoD!=null) 
	        addTree(x.filhoD,coordX+dist ,coordY+50,f,i,nivel+1,larg);
	      
	    }
	    
	  }
	  public void draw(String s){
	    GraphDraw frame = new GraphDraw(s);
	    int h=findHeight(this.raiz);
	    int d=30;
	    int nos_nivel_h=(int) Math.pow(2,h+1);
	    //System.out.println(nos_nivel_h);
	    
	    int larguraFrame=d*(nos_nivel_h +1);
	    int alturaFrame=70*(h+1);
	    //System.out.println(alturaFrame);
	    //System.out.println("Largura="+larguraFrame);
	    frame.setSize(larguraFrame,alturaFrame);
	 
	    frame.setVisible(true);
	    if (this.raiz!=null)
	      addTree(raiz, larguraFrame/2,50,frame,-1,1,larguraFrame);   
	    else
	      frame.setSize(50,150);	    
	  }
}
	
