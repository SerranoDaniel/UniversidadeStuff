import java.util.Scanner;

public class Expressoes {
	public static void main(String[] args){		
	while(true){	
		System.out.println("\nInsira a sua express�o em infix:");
		Scanner scan = new Scanner(System.in);
		String input = scan.nextLine();
		String[] arrayS=fun.toArray(input);
			if(!fun.correct(arrayS)){
				System.out.println("\nExpress�o Incorreta\n");
			}
			else{
				String[] post=fun.arrayPost(arrayS);
				System.out.println("\nPostFix:");
				System.out.println(fun.Tree(post).toPostfix(fun.Tree(post).getRaiz()).toString2());
				System.out.println("\nResultado:");
				System.out.println(fun.Tree(post).avalia()+"\n");
				System.out.println("\nOperandos:");
				System.out.println(fun.Tree(post).toOperator(fun.Tree(post).getRaiz()).toString());
				System.out.println("\nLista PostFix:");
				System.out.println(fun.Tree(post).toPostfix(fun.Tree(post).getRaiz()).toString());
				(fun.Tree(post)).draw("Arvore");
			}
		}
	}
}


