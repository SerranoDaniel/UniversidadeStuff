
public class ArrayStack<T> implements Stack<T> {
	private  static final int capacity =100;
	private T[] x;
	private int t=-1;
	
	ArrayStack(){
		this(capacity);
	}
	
	public ArrayStack(int cap){
		x=  (T[]) new Object[capacity];
	}
	
	public int size(){
		return t+1;
	}
	
	public boolean isEmpty(){
		return t==-1;
	}
	
	public void push(T t1) throws IllegalStateException{
		if(size()==x.length)  throw new IllegalStateException("Stack is full");
		t++;
		x[t]=t1;
	}
	
	public T top(){
		if(isEmpty()){
			return null;
		}
		return x[t];
	}
	
	public T pop(){
		if(isEmpty()){
			return null;
		}
		T temp = x[t];
		t--;
		return temp;
	}
	
	public String toString(){
		String s= new String();
		for(int i=t; i>=0; i--){
			s+= x[i] +" ";			
		}
		return s;
	}	

}
