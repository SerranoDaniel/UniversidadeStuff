
public class BinaryTree<T>{
	public T elemento;
	public BinaryTree<T> filhoE;
	public BinaryTree<T> filhoD;
	
	public BinaryTree(T t, BinaryTree<T> e, BinaryTree<T> d){
		this.elemento=t;
		this.filhoE=e;
		this.filhoD=d;
	}
	
	public BinaryTree(T t){
		this(t, null, null);		
	}
	
	public T getElemento(){
		return this.elemento;
	}
	
	public boolean isFolha(){
		return this.filhoE==null && this.filhoD==null;
	}
	
	public BinaryTree<T> getE(){
		return this.filhoE;
	}
	
	public BinaryTree<T> getD(){
		return this.filhoD;
	}
}
