public class estest {
	public static void main(String[] args){
		Car c1 = new Car("A");
		Car c2 = new Car("B");
		Car c3 = new Car("C");
		Car c4 = new Car("D");
		Estacionamento e = new Estacionamento();
		e.E(c1);
		e.E(c2);
		e.R(c2);
		System.out.println(e.toString());
	}
}
