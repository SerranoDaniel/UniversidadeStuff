import Stack.ArrayStack;
import java.util.Random;

public class Estacionamento {
	ArrayStack<Car> e1 = new ArrayStack<Car>(10);
	ArrayStack<Car> e2;
	public static final int capacity =11;
	public Random m = new Random();
	public int position;
	public Boolean isIne1=false;
	public Boolean isIne2=false;
	public Boolean t=false;
	public Boolean removed=false;
	 

	Estacionamento(){
		e1 = new ArrayStack<Car>(10);
		e2 = new ArrayStack<Car>(10);
	}
	
	public Boolean isIn1(Car c){
		t = false;
		for(int i=0; i<e1.size();i++)
			if(e1.display(i)==c){
				t = true;
			}
		return t;
	}	
	public Boolean isIn2(Car c){
		t = false;
		for(int i=0; i<e2.size();i++)
			if(e2.display(i)==c){
				t = true;
			}
		return t;
	}
	
	public void R(Car c){
		if(this.isIn1(c)==true){
			for(int i=e1.size()-1; i>=0;i--){
				if((e1.display(i)).matricula==c.matricula){
					e1.pop();
					position = i;
					isIne1=true;
					removed=true;
				}
				else{
					e2.push(e1.pop());					
				}
			}
		}
		else if(this.isIn2(c)==true){
			for(int i=e2.size()-1; i>=0;i--){
				if((e2.display(i)).matricula==c.matricula){
					e2.pop();
					position = i;
					isIne2=true;
					removed=true;
				}
				else{
					e1.push(e2.pop());					
				}
			}
		}		
	}	
	
	public String E(Car c){
		String s = new String(); 
		int z = 0;
		if(e1.size()+e2.size()<capacity){
			if(removed!=true){
				z = m.nextInt(4);
				if(z%2==0){
					e1.push(c);
					s="inseriu";
				}
				else{
					e2.push(c);
					s="inseriu";
				}				
			}
			if(isIne1==true){
				e1.insert(position, c);
				s="inseriu";			
			}else if(isIne2==true){
				e2.insert(position, c);
				s="inseriu";			
			}
		}else{
			s="imposs�vel inserir, estacionamento cheio";
		}
		return s; 
	}
	
	public String toString(){
		String s = new String();
		s="e1\n"+ e1.toString() +"\ne2 \n"+ e2.toString();
		return s;
	}
}
