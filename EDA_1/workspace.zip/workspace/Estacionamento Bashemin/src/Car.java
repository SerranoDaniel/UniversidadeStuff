public class Car {
	public int moves;
	public String matricula;

	Car(String m){
		moves = 0;
		this.matricula = m;
	}
}