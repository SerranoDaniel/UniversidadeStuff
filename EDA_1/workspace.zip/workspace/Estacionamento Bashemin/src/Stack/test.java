package Stack;
public class test{
	public static void main(String[] args){
		ArrayStack<Integer> x1= new ArrayStack<Integer>(10);
		x1.push(23);
		System.out.println(x1.size());
	}	
}
