package Stack;
public class test{
	public static void main(String[] args){
		ArrayStack<Integer> x1= new ArrayStack<Integer>(10);		
	}	
}
