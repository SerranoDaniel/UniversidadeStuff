import java.util.ArrayList;

public class fila<T> implements FilaEspera<T>{
	private int size;
	ArrayList<T> lista;
	
	fila(int size){
		this.size=size;
		lista = new ArrayList<T>(size);		
	}
	
	public int size(){
		return lista.size();
	}
	
	public int maxSize(){
		return this.size;
	}

	public int places(){
		return (this.size - lista.size());
	}
	
	public boolean isFull(){
		return (this.size == lista.size());
	}
	
	public boolean isEmpty(){
		return lista.isEmpty();
	}
	
	public void add(T t){
		lista.add(t);
	}
	
	public T front(){
		return lista.get(0);
	}
	
	public T remove(){
		T t=lista.remove(0);
		return t;		
	}
	
	public String element(){
		String el = new String();
		for(int i=0; i<lista.size(); i++){
			el=lista.get(i)+",";
		}
		return el;
	}
	
	public int compareTo(FilaEspera<?> x){
		int i=0;
		if(x.size()>this.size()){
			i=1;
		}
		else if(x.size() == this.size()){
			i=0;
		}
		else if(x.size()<this.size()){
			i=-1;
		}
		return i;
	}
}