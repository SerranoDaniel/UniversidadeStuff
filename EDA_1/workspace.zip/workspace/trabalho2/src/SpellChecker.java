import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class SpellChecker {
String erro;
String texto;
LinHashTable<String> dicionario;
QuadHashTable<String> sugestoes;


	SpellChecker(String dicionarioFile, String errorFile, String textoFile) throws IOException{
		this.texto = textoFile;
		this.erro = errorFile;
		this.diciToHash(dicionarioFile);		
	}
	
	public void diciToHash(String docFile) throws IOException{
		dicionario = new LinHashTable<String>();
		FileInputStream fstream = new FileInputStream(docFile);
		DataInputStream in = new DataInputStream(fstream);
		BufferedReader br = new BufferedReader(new InputStreamReader(in));
		String strLine;
		
		while ((strLine = br.readLine()) != null){			
			dicionario.insert(strLine);			
		}
		in.close();
		System.out.println("Tamanho da HashTable Dicionario: " + dicionario.array.length + "\n");
		System.out.println("Numero de elementos inseridos: " + dicionario.places + "\n");
		System.out.println("Factor de Carga: " + dicionario.factorCarga() + "\n");
	}
	
	public void spellCheck(String s) throws FileNotFoundException{
		sugestoes = new QuadHashTable<String>();
		File texto = new File(s);
		Scanner input = new Scanner(texto);  
		String temp;
		while(input.hasNext()) {
			temp = input.next();
		   if(dicionario.search(temp)==null){
			   sugestoes.insertsuggest(temp);
			   int z = sugestoes.procPos(temp);
			   corrector(temp, z);
		   }
		}
	}
	
	public String toStringsuggest() throws IOException{
		File sugestxt = new File(erro);
		sugestxt.createNewFile();
		FileWriter fw = new FileWriter(sugestxt);		
		String s = "";
		for(int i=0; i<sugestoes.array.length; i++){
			if(sugestoes.array[i]!=null && !sugestoes.array[i].isEreased()){
				s+="Palavra errada: " + sugestoes.array[i].getElemento() + "\n";
				fw.write("Palavra errada: " + sugestoes.array[i].getElemento() + "\r\n");
				if((sugestoes.array[i].print()).equals("")){
					s +="Nao existem sugestoes" +"\n"+"\n";
					fw.write("Nao existem sugestoes" +"\r\n"+"\r\n");
				}
				else{
					s +="Sugestoes: " + sugestoes.array[i].print() + "\n"+"\n";
					fw.write("Sugestoes: " + sugestoes.array[i].print() + "\r\n"+"\r\n");
				}				
			}
		}
		fw.close();
		return s;
	}

	public void corrector(String word, int k){
		StringBuilder temp = new StringBuilder(word);
		//remove character
		for(int i=0; i<=word.length()-1;i++){
			temp.deleteCharAt(i);
			if(dicionario.search(temp.toString())!=null){
				if(!sugestoes.array[k].words.contains(temp.toString())){
					sugestoes.array[k].addElement(temp.toString());
				}
			}			
			temp = new StringBuilder(word);
		}
		//add character
		for(int i=0; i<word.length();i++){
			for(int z='a'; z<='z'; z++){
				char tempi = (char) z;
				temp.insert(i,tempi);
				if(dicionario.search(temp.toString())!=null){
					if(!sugestoes.array[k].words.contains(temp.toString())){
						sugestoes.array[k].addElement(temp.toString());
					}
				}
				temp = new StringBuilder(word);
			}			
		}
		//switch adjacent character
		temp = new StringBuilder(word);
		for(int i=0; i<=word.length()-2; i++){
			char offset1 = word.charAt(i);
			char offset2 = word.charAt(i+1);
			temp.setCharAt(i+1, offset1);
			temp.setCharAt(i, offset2);
			if(dicionario.search(temp.toString())!=null){
				if(!sugestoes.array[k].words.contains(temp.toString())){
					sugestoes.array[k].addElement(temp.toString());
				}
			}			
			temp = new StringBuilder(word);		
		}
		//switch characters
		for(int i=0; i<word.length();i++){
			for(int z='a'; z<='z'; z++){
				char tempi = (char) z;
				temp.setCharAt(i, tempi);
				if(dicionario.search(temp.toString())!=null){
					if(!sugestoes.array[k].words.contains(temp.toString())){
						sugestoes.array[k].addElement(temp.toString());
					}
				}
				temp = new StringBuilder(word);
			}			
		}
	}	
}
