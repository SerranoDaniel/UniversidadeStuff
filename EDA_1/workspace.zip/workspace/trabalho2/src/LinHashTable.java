import java.lang.*;
public class LinHashTable<T> extends HashTable<T>{
	
	public LinHashTable(int size){
		super(size);
	}
	
	public LinHashTable(){
		super();
	}

	protected int procPos(T t) {
		int hash = Math.abs(t.hashCode()) % array.length;
		
		if(array[hash]==null){
			return hash;
		}
		else if(!array[hash].isEreased() && (array[hash].getElemento()).equals(t)){
			return hash;
		}
		else{
			while(array[hash]!=null && !(array[hash]).isEreased()){
				if(t.equals(array[hash].getElemento())){
					return hash;
				}
				else{
					hash=(hash+1) % array.length;
				}
			}
			return hash;
		}
	}
}
