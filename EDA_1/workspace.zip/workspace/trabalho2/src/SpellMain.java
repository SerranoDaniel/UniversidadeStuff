import java.io.IOException;

public class SpellMain {

	public static void main(String[] args) throws IOException {
		/* 
		 * 1- Nome e extensao do ficheiro do dicionario
		 * 2- Nome e extensao do ficheiro de sugestoes a criar
		 * 3- Nome do ficheiro de palavras a corrigir
		 * 
		 * SpellChecker(1 , 2, 3);
		 */
		SpellChecker a = new SpellChecker("input.txt", "erros.txt", "flora.txt");
		a.spellCheck(a.texto);
		System.out.println(a.toStringsuggest());		
	}	
}
