import java.util.Arrays;
public abstract class HashTable<T>{
	protected Element<T>[] array;
	public int places;
	private static final int SIZE = 1; 
	
	public HashTable(){
		this(SIZE);
	}
	
	public HashTable(int size){
		array = new Element[minPrime(size)];
		this.places = 0;
	}
	
	protected abstract int 	procPos	(T s);
	
	public int ocupados(){
		return places;
	}
	
	public float factorCarga(){
		float t = (float)places/(array.length);
		return t;
	}
	
	public void makeEmpty(){
		Arrays.fill(array, null);
	}
	
	public void insert(T t){
		int pos = procPos(t);
		if(array[pos]!=null && !array[pos].isEreased() && (array[pos].getElemento()).equals(t)){
			return;
		}
		array[pos] = new Element<T>(t);
		places++;
		double fact = factorCarga();
		if(fact>=0.5){
			reash();
		}		
	}
	
	public void insertsuggest(T t, LinkedList<String> x){
		int pos = procPos(t);
		if(array[pos]!=null && !array[pos].isEreased() && (array[pos].getElemento()).equals(t)){
			return;
		}
		array[pos] = new Element<T>();
		array[pos].setElemento(t);
		array[pos].words = x;
		places++;
		double fact = factorCarga();
		if(fact>=0.5){
			reashsuggest();
		}		
	}
	public void insertsuggest(T t){
		int pos = procPos(t);
		if(array[pos]!=null && !array[pos].isEreased() && (array[pos].getElemento()).equals(t)){
			return;
		}
		array[pos] = new Element<T>();
		array[pos].setElemento(t);
		places++;
		double fact = factorCarga();
		if(fact>=0.5){
			reashsuggest();
		}		
	}
	
	public T search(T t){
		int temp = procPos(t);
		if(array[temp]==null){
			return null;
		}
		else if(array[temp].getElemento().equals(t) && !array[temp].isEreased()){
			return t;
		}
		else{
			return null;
		}
	}
		
	public void newTabela(){
		array =  new Element[minPrime((array.length)*2)];		
		places = 0;
	}
	
	public void remove(T t){
		int temp = procPos(t);
		if(array[temp].getElemento().equals(t)){
			array[temp].setEreased(true);
		}
	}
	
	public void reash(){
		Element<T>[] old = array;
		this.newTabela();
		
		for(int i = 0; i<old.length;i++){
			if(old[i]!=null && !old[i].isEreased()){
				this.insert(old[i].getElemento());
			}
		}
	}
	
	public void reashsuggest(){
		Element<T>[] old = array;
		this.newTabela();
		
		for(int i = 0; i<old.length;i++){
			if(old[i]!=null && !old[i].isEreased()){
				this.insertsuggest(old[i].getElemento(), old[i].words);
			}
		}
	}
		
	public boolean isPrime(int n){
		if(n%2 == 0){
			return false;
		}
		
		for(int i=3; i*i<=n; i+=2){
			if(n%i==0){
				return false;
			}
		}
		return true;
	}
	
	public int minPrime(int n){
		while(!isPrime(n)){
			n++;
		}
		return n;
	}
	
	public int prevPrime(int n){
		n--;
		while(!isPrime(n)){
			n--;
		}
		return n;
	}
	
	public void tostring(){
		
		for(int i=0; i<array.length;i++){
			if(array[i]==null){
				System.out.println("null");
			}
			else{
			System.out.println(array[i].getElemento());
			}
		}
		System.out.println(array.length);
		System.out.println(places);
		System.out.println(factorCarga());
	}
}
