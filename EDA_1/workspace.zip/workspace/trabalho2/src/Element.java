public class Element<T> {
	public T elemento;
	public boolean erease;
	LinkedList<String> words;
	
	Element(T t){
		this.elemento = t;
		this.erease=false;
	}
	
	Element(){
		words = new LinkedList<String>();
		this.erease = false;
	}
	
	public void setElemento(T t){
		this.elemento = t;
	}
	
	public T getElemento(){
		return elemento;
	}
	
	public boolean isEreased(){
		return erease;
	}
	
	public void setEreased(boolean b){
		this.erease = b;
	}
	
	public void addElement(String t){
		words.add(t);
	}
	
	public String print(){
		return words.toString();
	}
}
