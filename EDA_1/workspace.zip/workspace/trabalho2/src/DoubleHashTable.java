import java.lang.*;
public class DoubleHashTable<T> extends HashTable<T>{

	public DoubleHashTable(int size){
		super(size);
	}
	
	public DoubleHashTable(){
		super();
	}
	
	protected int procPos(T t) {
		int hash = Math.abs(t.hashCode()) % array.length;
				
		if(array[hash]==null){
			return hash;
		}
		else if(!array[hash].isEreased() && (array[hash].getElemento()).equals(t)){
			return hash;
		}
		else{
			int temp = this.prevPrime(array.length);
			int hash2 =(temp-(t.hashCode()%temp));
			//hash+=hash2;
			while(array[hash]!=null && !(array[hash]).isEreased()){
				if(t.equals(array[hash].getElemento())){
					return hash;
				}
				else{
					hash = (hash + hash2) % array.length;
				}
			}
			return hash;
		}	
	}
}
