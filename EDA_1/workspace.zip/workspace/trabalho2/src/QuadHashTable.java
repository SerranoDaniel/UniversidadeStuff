import java.lang.*;
public class QuadHashTable<T> extends HashTable<T>{
	
	public QuadHashTable(int size){
		super(size);
	}
	
	public QuadHashTable(){
		super();
	}

	protected int procPos(T t) {
		int hash = Math.abs(t.hashCode()) % array.length;
		int i=1;
		
		if(array[hash]==null){
			return hash;
		}
		else if(!array[hash].isEreased() && (array[hash].getElemento()).equals(t)){
			return hash;
		}
		else{
			while(array[hash]!=null && !(array[hash]).isEreased()){
				if(t.equals(array[hash].getElemento())){
					return hash;
				}
				else{
					hash =(int)(hash + Math.pow(i,2)) % array.length;
				}
			}
			return hash;
		}
	}

}
