public class BinarySearchTree<T extends Comparable<? super T>> {
	
	BinaryNode<T> raiz;

	
	public BinarySearchTree(){
		raiz=null;
	}
	
	public void makeEmpty(){
		raiz=null;
	}
	public boolean isEmpty(){
		return raiz==null;
	}
	

	public boolean contains(T x){
		return contains(x, raiz);
	}	
	private boolean contains(T x, BinaryNode<T> n){
		if(n==null){
			return false;
		}
		else{
			if(n.elemento.compareTo(x)<0){
				return contains(x, n.direito);
			}
			else{
				if(n.elemento.compareTo(x)>0){
					return contains(x, n.esquerdo);
				}
				else{
					return true;
				}
			}
		}
	}

	
	public T findMin(){
		if(isEmpty()){
			return null;
		}
		return findMin(raiz);
	}
	private T findMin(BinaryNode<T> n){
		if(n.esquerdo==null){
			return n.elemento;
		}
		return findMin(n.esquerdo);
	}	
	
	public T findMax(){
		if(isEmpty()){
			return null;
		}
		return findMax(raiz);
		
	}
	private T findMax(BinaryNode<T> n){
		if(n.direito==null){
			return n.elemento;
		}
		return findMax(n.direito);
	}
		
	
	public void insert(T x){
		raiz=insert(x, raiz);
	}
	private BinaryNode<T> insert(T x, BinaryNode<T> n){
		if(n==null){
			n=new BinaryNode<T>(x,null,null);
		}
		else{
			if(n.elemento.compareTo(x)>0){
				n.esquerdo=insert(x,n.esquerdo);
			}
			else{
				if(n.elemento.compareTo(x)<0){
					n.direito=insert(x,n.direito);
				}
			}
		}
		return n;
	}
		
	
	public void remove(T x){
		raiz=remove(x, raiz);
	}
	private BinaryNode<T> remove(T x, BinaryNode<T> n){
		if(n==null){
			return n;
		}
		if(n.elemento.compareTo(x)<0){
			n.direito=remove(x,n.direito);
		}
		else{
			if(n.elemento.compareTo(x)>0){
				n.esquerdo=remove(x,n.esquerdo);
			}
		
			else{
				if(n.esquerdo!=null && n.direito!=null){
					T min=findMin(n.direito);
					n.elemento=min;
					n.direito=remove(min,n.direito);
				}
			
				else{
					if(n.esquerdo==null){
						n=n.direito;
					}
				
					else{
						n=n.esquerdo;
						}
					}
			}
		}
					return n;
			
	}
	
	
	public void printTree(){
		if(isEmpty()){
			System.out.println("Árvore Vazia");
		}
		else{
			printTree(raiz);
		}
	}
	
	private void printTree(BinaryNode<T> x){
		if(x!=null){
			printTree(x.esquerdo);
			System.out.println(x.elemento);
			printTree(x.direito);
		}
	}
	
		

}
