public class BinaryNode<T> {
	
	T elemento;
	BinaryNode<T> esquerdo;
	BinaryNode<T> direito;
	
	BinaryNode(T elemento){
		this(elemento, null, null);
	}
	
	BinaryNode(T x, BinaryNode<T> esq, BinaryNode<T> dir){
		elemento=x;
		esquerdo=esq;
		direito=dir;
	
	}

}
