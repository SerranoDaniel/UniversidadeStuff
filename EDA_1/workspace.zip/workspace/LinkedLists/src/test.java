public class test {

	public static void main(String[]args){
		LinkedList<String> l1 = new LinkedList<String>();
		System.out.println(l1.size());
		l1.add("1");
		l1.add("2");
		l1.add("3");
		l1.add("4");		
		System.out.println(l1.size());
		System.out.println(l1.toString());
		System.out.println(l1.getNode(0).getElemento());
		System.out.println(l1.contains("0"));
	}
}
