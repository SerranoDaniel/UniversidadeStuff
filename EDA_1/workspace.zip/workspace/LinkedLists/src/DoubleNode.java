public class DoubleNode<T> {
	private T item;
	DoubleNode<T> next;
	DoubleNode<T> prev; 
	
	DoubleNode(){
		item=null;
		next=null;
		prev=null;
	}
	
	DoubleNode(T t){
		item=t;
		next=null;
		prev=null;
	}
	
	DoubleNode(DoubleNode<T> s, T t ){
		next=s;
		item=t;
	}
	DoubleNode(T t, DoubleNode<T> s){
		prev=s;
		item=t;
	}
	
	DoubleNode(DoubleNode<T> s1, DoubleNode<T> s2, T t ){
		next=s1;
		prev=s2;
		item=t;
	}
	
	public T getElemento(){
		return this.item;
	}
	
	public void setElemento(T t){
		this.item=t;
	}
	
	public void setNext(DoubleNode<T> t){
		this.next=t;
	}
	
	public void setPrev(DoubleNode<T> t){
		this.prev=t;
	}
		
	public DoubleNode<T> getNext(){
		return this.next;
	}
	
	public DoubleNode<T> getPrev(){
		return this.prev;
	}
}
