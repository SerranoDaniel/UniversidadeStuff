/**
 * Created by JoaoManuel on 06/11/2017.
 */
public class InvalidNodeException extends Exception {

    public InvalidNodeException(){
        super();
    }

    public InvalidNodeException(String string){
        super(string);
    }
}
