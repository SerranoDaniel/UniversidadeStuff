public class OverflowQueueException extends RuntimeException{

  public OverflowQueueException(){}
  
  public OverflowQueueException(String message){
  super(message);
  }
}