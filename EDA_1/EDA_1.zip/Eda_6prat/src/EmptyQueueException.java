/**
 * Created by User on 30/10/2017.
 */
public class EmptyQueueException extends Exception{

    public EmptyQueueException(){
        super();
    }

    public EmptyQueueException(String s){
        super(s);
    }
}
