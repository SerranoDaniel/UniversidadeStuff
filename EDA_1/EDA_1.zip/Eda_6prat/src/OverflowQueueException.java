/**
 * Created by User on 30/10/2017.
 */
public class OverflowQueueException extends Exception{

    public OverflowQueueException(){
        super();
    }

    public OverflowQueueException(String s){
        super(s);
    }
}
