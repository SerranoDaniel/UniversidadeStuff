/**
 * Created by JoaoManuel on 25/09/2017.
 */

public class Teste {

    public static void main(String[] args){

        Fraccoes obj1 = new Fraccoes(10,20);
        Fraccoes obj2 = new Fraccoes(20,50);
        Fraccoes obj3 = new Fraccoes(50,100);

        obj1.toString();

        obj1.reduce();

        obj1.toString();



    }






}
