package EDA1;

/**
 * Created by User on 21/12/2017.
 */
public class EmptyException extends Exception {

    public EmptyException(){
        super();
    }
    public EmptyException(String x){
        super(x);
    }

}
