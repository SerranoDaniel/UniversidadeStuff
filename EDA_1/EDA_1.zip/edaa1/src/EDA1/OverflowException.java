package EDA1;

/**
 * Created by User on 22/12/2017.
 */
public class OverflowException extends Exception {
    public OverflowException(){
        super();
    }

    public OverflowException(String x){
        super(x);
    }
}
