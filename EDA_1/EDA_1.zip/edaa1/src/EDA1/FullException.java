package EDA1;

/**
 * Created by User on 21/12/2017.
 */
public class FullException extends Exception{
    public FullException(){
        super();

    }

    public FullException(String x){
        super(x);
    }
}
