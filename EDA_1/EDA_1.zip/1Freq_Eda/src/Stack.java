/**
 * Created by User on 25/10/2017.
 */
public interface Stack <E>{
public void push(E o);
public E top();
public E pop();
public int size();
public boolean empty();
}

