/**
 * Created by User on 16/10/2017.
 */
public class EmptyException extends Exception {

    public EmptyException(){
        super();
    }
    public EmptyException(String x){
        super(x);
    }

}
