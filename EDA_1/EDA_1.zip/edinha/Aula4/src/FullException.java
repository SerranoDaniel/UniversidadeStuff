/**
 * Created by User on 16/10/2017.
 */
public class FullException extends Exception{
    public FullException(){
        super();

    }

    public FullException(String x){
        super(x);
    }
}
