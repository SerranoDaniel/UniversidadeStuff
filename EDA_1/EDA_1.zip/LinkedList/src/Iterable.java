
public interface Iterable<T> {
	java.util.Iterator<T> iterator();
}
