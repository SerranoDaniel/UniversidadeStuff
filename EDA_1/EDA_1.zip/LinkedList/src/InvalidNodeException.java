
public class InvalidNodeException extends RuntimeException{
	
	public InvalidNodeException(){
		super();
	}
	
	public InvalidNodeException(String  s) {
		super(s);
	}
}
