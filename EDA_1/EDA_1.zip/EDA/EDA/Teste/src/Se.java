
public class Se {
	public static void main(String[] args) {
		Obk o = new Obk();
		o.buil();
	}
}
