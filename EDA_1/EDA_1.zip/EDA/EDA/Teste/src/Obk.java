import javax.swing.JFrame;


public class Obk {
	public void buil(){
		JFrame frame = new JFrame();
		frame.setSize(500, 500);
		frame.setVisible(true);
	}
}
