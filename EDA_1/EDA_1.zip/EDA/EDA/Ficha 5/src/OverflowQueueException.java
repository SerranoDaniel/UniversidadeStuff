
public class OverflowQueueException extends RuntimeException {
	public OverflowQueueException(){
		super();
	}
	public OverflowQueueException(String str){
		super(str);
	}

}
