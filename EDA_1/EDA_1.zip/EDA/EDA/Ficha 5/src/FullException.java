
public class FullException extends RuntimeException {
	public FullException(){
		super();
	}
	public FullException(String str){
		super(str);
	}
}
