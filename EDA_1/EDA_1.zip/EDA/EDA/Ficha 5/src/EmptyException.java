
public class EmptyException extends RuntimeException {
	public EmptyException(){
		super();
	}
	public EmptyException(String str){
		super(str);
	}
}
