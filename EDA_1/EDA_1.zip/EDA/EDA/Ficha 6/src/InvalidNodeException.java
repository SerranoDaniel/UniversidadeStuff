
public class InvalidNodeException extends RuntimeException {
	public InvalidNodeException(){
		super();
	}
	public InvalidNodeException(String str){
		super(str);
	}

}