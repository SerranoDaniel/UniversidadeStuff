
public class LinkedList {

}
