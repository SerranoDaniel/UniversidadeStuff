package EDA1;

/**
 * Created by User on 23/12/2017.
 */
public class InvalidNodeException extends Exception {

    public InvalidNodeException(){
        super();
    }

    public InvalidNodeException(String string){
        super(string);
    }
}

